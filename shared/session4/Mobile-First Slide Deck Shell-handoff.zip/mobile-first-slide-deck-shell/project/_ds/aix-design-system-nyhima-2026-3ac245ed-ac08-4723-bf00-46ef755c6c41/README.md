# AIX Design System — NYHIMA 2026

**SUNY Poly AIX Center · Steve Schneider**
A design system for two linked academic events at the **New York Health Information Management Association (NYHIMA)** conference, June 2026.

> Two events. One design family. Distinguished by **color temperature, not structure.**

---

## What this is

This is **not** a software product. It is a **document & presentation design system** for delivering an AI-literacy curriculum to health-information-management (HIM) professionals. The "products" are presentation slides, printed handouts, and scenario cards — all generated as HTML.

| | **Workshop** | **Talk** |
|---|---|---|
| **Title** | Reading and Writing with AI | Why Universal AI Literacy Matters |
| **Date** | Sunday, June 7, 2026 | Tuesday, June 9, 2026 |
| **Duration** | 3 hours (1:00–4:00 PM) | 1 hour |
| **Surface** | **Navy** dominant (`#002C73`) | **AIX Ink** dominant (`#0D1B2A`) |
| **Accent** | **Gold** (decorative) | **Signal** blue (`#00B4D8`) |
| **Energy** | Practitioner, hands-on, activating | Argumentative, conceptual, editorial |

Both share: the same type stack, the same structural components, the same dimensional palette, and the same SUNY Poly logo. The only thing that changes between them is the surface color and the accent — that is the entire identity system.

### The curriculum, in one breath
The Workshop runs **three sprints** (Data → Policy → Judgment) across **twelve HIM scenarios**. Participants run real scenarios through **two AI models**, make the models argue, and leave with a portable "workbench" of artifacts. The load-bearing rhetorical move is the opening question **"Who prompted that?"** — returned to in the wrap. The one thing to leave them with: *"Literacy isn't knowing how to prompt. It's knowing when to push back."*

### The Voxel framework (dimensional palette)
Scenarios are tagged along a 5-dimension framework, each mapped to a fixed color (cool→warm arc): D1 cognitive_mode, D2 failure_mode, D3 ai_visibility, D4 output_type, D5 stakes. These colors **encode meaning** — they are not decorative.

---

## Sources I was given

- **`uploads/aix-design-system.md`** — the authoritative design spec (colors, type, components, rules). This README and the CSS are a faithful materialization of it.
- **Codebase `2026-06-nyhima-ai-for-all/`** (read-only mount) — workshop content:
  - `workshop-scenarios/` — 12 scenario files (D1–D4, P1–P4, J1–J4) + `INDEX.md`
  - `workshop-scripts/` — facilitator deck (`nyhima-facilitator-deck.md`, 22 slides), per-segment scripts (`00-opening`…`05-wrap`), `participant-reference-card.md`, `system-prompts.md` (SP-00…SP-06)
  - `2026-05-26-*.md` — design-rationale conversation notes
  - `AHIMA Domains.pdf` — reference (HIM professional domains)
- **External:** SUNY Poly AIX Center — `sunypolyaix.github.io` · contact `steve@sunypoly.edu` · everything lives at `tiny.cc/nyhima`

> ⚠️ The **Talk** ("Why Universal AI Literacy Matters") has no slide content in the codebase yet — only its identity (Ink + Signal) is specified. The Talk kit demonstrates the surface treatment with representative copy; swap in real content when available.

---

## CONTENT FUNDAMENTALS

**Tone.** Direct, confident, practitioner-to-practitioner. Never breathless about AI. The voice respects the audience's expertise and is faintly skeptical of the technology. It is *argumentative and editorial*, not promotional. Sentences are short and declarative. Fragments are used deliberately for weight: *"That's your workbench. It's yours."*

**Person.** Second person **"you"** addressing the participant directly ("By 4:00 PM you have artifacts you generated"). First person singular appears only as the facilitator's spoken voice in scripts ("I want to ask you a question"). Never corporate "we" as a brand.

**Casing.** Sentence case for almost everything — titles, headings, buttons. **ALL-CAPS only** for mono metadata labels (scenario codes, dates, "NYHIMA 2026"), always with wide letter-spacing. Never all-caps for headlines.

**The provocation line.** The signature device: a short, italic, serif rhetorical line that does the heavy lifting. Examples: *"Who prompted that?"*, *"The model is a variable, not a constant."*, *"A model that sounds authoritative about law is a specific kind of dangerous."*, *"You get out what you put in."* These are always set in italic display serif — never sans.

**Emphasis.** Bold is used sparingly, for the single load-bearing phrase in a block (**"That's the goal."**). Blockquotes carry the aphorisms.

**Numbers & structure.** Tables and numbered step-lists are heavily used (sprint cycles, timing guides, scenario indexes). Codes are systematic: `SP-01`, `D1`, `J3`, `tiny.cc/nyhima`. Scenario titles use a definite-article pattern: *"The Discharge Data"*, *"The Physician Who Won't Document"*, *"The AI Note in the Chart"*.

**Emoji.** **None.** This is an institutional, academic, healthcare-compliance context. No emoji anywhere. Unicode is limited to typographic punctuation (em dashes, middots `·`, arrows `→`).

**What it never does.** Doesn't explain what an LLM is. Doesn't apologize for the tech. Doesn't promise AI will be impressive. Doesn't end on "AI is changing everything." Doesn't summarize lessons the audience just lived.

---

## VISUAL FOUNDATIONS

**The core idea.** Identity = surface color + accent. Structure is constant. You can tell Workshop from Talk in a quarter-second by whether the background is Navy-with-gold or Ink-with-cyan.

**Color.**
- **Workshop** lives on **Navy `#002C73`** (SUNY Poly brand primary, PMS 288) with **Gold `#EDA900`** accents.
- **Talk** lives on **AIX Ink `#0D1B2A`** (deeper, cooler than Navy — *not interchangeable*) with **Signal `#00B4D8`** accents.
- **Handouts / print** live on **Cream `#FAF8F3`** with Navy text and gold rules.
- The **Dimensional palette** (D1 cyan → D5 rose) is a cool-to-warm arc used for framework diagrams and scenario bucket bars. On dark surfaces the saturated hex is used as fill with Navy text on top; on light surfaces a pale tint-bg + saturated border + dark text.

**The Gold Rule (the single most important motif).** Gold `#EDA900` is **decorative only — never text, on any surface, ever** (it fails contrast on both Navy and Cream). Its primary expression: every title block opens with a **2px × 32px horizontal rule**. Gold for Workshop & handouts; **Signal blue** for the Talk. This little rule is the fastest identity signal in the system — get its color right and the rest follows.

**Typography.** Display is serif (two options — see below); body is **IBM Plex Sans Light (300)**; metadata is **IBM Plex Mono**. The mix of a humanist/academic serif for headings + light grotesque body + mono labels gives the "institutional technology" feel. Body weight is genuinely light (300) — this is load-bearing, not a default. Provocation/quote lines are *italic serif*.

**Backgrounds.** Flat solid color fills — **no gradients, no photography, no illustration, no texture, no patterns.** The surface *is* the design. Dark surfaces are pure Navy or pure Ink; light surfaces are pure Cream. This restraint is intentional and institutional.

**Modes (surface themes).** The same content renders in two **modes** — system-wide surface themes that keep structure, type, components, and the gold rule constant and flip only the surface: **Stage** (Navy/Ink, for dim rooms, LED walls, brand feel) and **AIX Presentation Mode** (Cream, dark text, high contrast for hotel projectors and back-row legibility). This is a *mode/theme*, not a component "variant." On light, round accents use their dark-tone (`--acc-dark`) + pale-tint (`--acc-tint`) pairs, and links become navy text with a decorative gold underline — gold never becomes text.

**Cards.** Light scenario cards: Cream fill, **0.5px hairline border `#E0DDD6`**, **10px radius**, `overflow:hidden`, and a **4px colored top bar** carrying the dimensional/bucket color. No drop shadows. The look is flat, printed, editorial — like a well-set reference card, not a web app.

**Pills.** Identity pills are fully-rounded (`12px` radius), tiny (10px text), and color-coded: gold-on-navy for Workshop, signal-on-ink for Talk, navy outline for the AIX Center, mono on cream for metadata.

**Chips.** Dimensional chips on dark surfaces are small `6px`-radius solid color blocks with Navy text and a mono sub-label showing the dimension code + hex.

**Borders & rules.** Hairlines everywhere (0.5px–1.5px). The gold/signal identity rule is 2px. Contrast-note blocks use a 3px left border in gold over a pale `#FFF9E0` background (the one sanctioned "left-border accent" pattern, used only for facilitator/compliance notes).

**Shadows.** Essentially none. This is a flat, print-derived system. Elevation is communicated by color and border, not shadow.

**Radii.** `6px` chips · `10px` cards · `12px` pills. Rules and bars are sharp (0 radius).

**Animation.** None required. These are slides and print artifacts. If motion is added (e.g. slide entrances), keep it to simple fades — no bounces, no decorative loops — and respect `prefers-reduced-motion`.

**Hover / press.** Not a defining concern (print + slides). For any interactive recreation, keep states quiet: subtle opacity or a one-step-darker fill on hover; no scale-bounce.

**Transparency & blur.** No blur. Transparency is used only as the white-on-dark text opacity ramp (100/85/75/65/40%) that builds the text hierarchy on Navy and Ink.

**Imagery vibe.** There is no photographic imagery in the system. If imagery is ever introduced it should be cool, restrained, and editorial — but the default is *no imagery at all.*

**Accessibility.** WCAG AA is the floor; most pairings hit AAA. The spec ships a verified-contrast table. Gold-as-text is banned precisely because it fails. Check every text/background pair against the table before finalizing.

---

## ICONOGRAPHY

The brand is **deliberately icon-light.** There is no icon font, no SVG icon set, and no emoji in the source material. Meaning is carried by **color (the dimensional palette), typography, and the gold/signal rule** — not by pictograms.

- **Logo / wordmark:** The **official SUNY Poly abbreviated wordmark** now ships in `assets/` as transparent PNGs — stacked (`-navy` / `-white`) and horizontal (`-horizontal-navy` / `-white`) — extracted directly from the University Brand Guide (Approved Wordmarks, p.9). **Approved colors only:** PMS 288 navy `#002C73`, white reverse, or black; never re-typeset or recolor, and preserve clear-space equal to the height of the “S”. The full “SUNY POLYTECHNIC INSTITUTE” wordmark, primary seal logo, and college logos exist in the brand guide but are not yet extracted — request if needed.
- **Unicode as ornament:** middot `·`, em dash `—`, and arrow `→` are the only "icons" in regular use (e.g. `Workshop · June 7`, `tiny.cc/nyhima → scenarios/`).
- **Color bars / chips** stand in for icons on cards — the 4px dimensional top-bar identifies a scenario's bucket faster than any glyph would.
- **If icons are ever needed** (e.g. for a future interactive surface), use a thin-stroke, geometric, single-weight set — Lucide (1.5–2px stroke) is the closest CDN match to the system's restrained, institutional feel. Link from CDN and keep them monochrome (Navy on light, white on dark). **Flag any such addition** as an extension beyond the source spec.

---

## INDEX — what's in this system

**Foundations**
- `README.md` — this file
- `colors_and_type.css` — all CSS custom properties + semantic element classes (both type options)
- `uploads/aix-design-system.md` — the original authoritative spec

**Assets** — `assets/`
- `suny-poly-wordmark-navy.png` / `-white.png` — **official** abbreviated wordmark (stacked), PMS 288 / white reverse, extracted from the University Brand Guide (p.9)
- `suny-poly-wordmark-horizontal-navy.png` / `-white.png` — official abbreviated wordmark (horizontal)
- `aix-center-lockup-navy.svg` / `-white.svg` — AIX Center lockup for light / dark surfaces (unofficial unit mark — see note)

**Design System cards** — `preview/` (registered to the Design System tab): color palettes, dimensional palette, type specimens & scale, the gold rule, spacing/radii, and components (pills, chips, cards, note blocks).

**Kits** — `ui_kits/`
- `slides/` — presentation kit. **`Facilitator Deck.html`** is the full v3 workshop deck in **Stage mode** (Navy); **`Facilitator Deck - Presentation Light.html`** is the same deck in **AIX Presentation Mode** (Cream, high-contrast for projectors); `index.html` is an 8-slide Workshop+Talk sampler.
- `handouts/` — print kit: participant reference card + scenario cards (Data / Policy / Judgment). Open `ui_kits/handouts/index.html`.

**Skill**
- `SKILL.md` — makes this folder usable as a downloadable Claude Skill.

---

## TYPOGRAPHY — Option B locked in

Body & mono are always IBM Plex Sans / Mono. The **display face is locked to Option B — IBM Plex Serif** (precise, technical-academic; no AI-product associations). This is the default everywhere in `colors_and_type.css`.

Option E (EB Garamond) remains available as an override: add `data-type="E"` to any wrapper to switch that subtree to Garamond.
